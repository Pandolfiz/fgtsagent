module.exports = {
  requireAuth: require('./auth').requireAuth,
  clientContext: require('./clientContext'),
  // ... você pode adicionar outros middlewares aqui se desejar
}; 