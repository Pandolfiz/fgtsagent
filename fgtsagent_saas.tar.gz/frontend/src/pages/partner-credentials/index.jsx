import { PartnerCredentialsPage } from '../../components/partner-credentials/PartnerCredentialsPage';

export default PartnerCredentialsPage; 