import { EvolutionCredentialsPage } from '../../components/evolution-credentials/EvolutionCredentialsPage';

export default EvolutionCredentialsPage; 