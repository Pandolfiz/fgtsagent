import { EvolutionCredentialsPage } from '../components/whatsapp-credentials/EvolutionCredentialsPage'

export default function EvolutionCredentialsRoute() {
  return <EvolutionCredentialsPage />
} 