import React from 'react';
export default function Profile() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-950 via-cyan-950 to-blue-950 text-white">
      <h1 className="text-3xl font-bold">Perfil do Usuário</h1>
    </div>
  );
} 